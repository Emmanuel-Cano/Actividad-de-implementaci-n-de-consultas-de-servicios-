let lista = document.getElementById("lista");
let input = document.getElementById("tarea");
let boton = document.getElementById("btnAgregar");

let tareas = JSON.parse(localStorage.getItem("tareas")) || [];

function mostrarTareas() {
    lista.innerHTML = "";

    for (let i = 0; i < tareas.length; i++) {
        let li = document.createElement("li");

        let check = document.createElement("input");
        check.type = "checkbox";
        check.checked = tareas[i].hecho;

        let texto = document.createElement("span");
        texto.textContent = tareas[i].texto;

        check.addEventListener("change", () => {
            tareas[i].hecho = check.checked;
            guardar();
        });

        li.appendChild(check);
        li.appendChild(texto);
        lista.appendChild(li);
    }
}

function guardar() {
    localStorage.setItem("tareas", JSON.stringify(tareas));
}

boton.onclick = function() {
    if (input.value !== "") {
        tareas.push({
            texto: input.value,
            hecho: false
        });
        input.value = "";
        guardar();
        mostrarTareas();
    }
};

mostrarTareas();
